
def () -> str:
    return 'do some magic!'
